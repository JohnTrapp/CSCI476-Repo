John Trapp and Brendan Bellows
Bonus Lab

What's included: BonusLab.java & Encryptor.java (& this readme)

How to run: BonusLab.java is the main file. Execute that.

NOTE:
We tried very hard on this lab at it works! The only problem is that,
for the life of us, we cannot figure out why it is not producing a
value the same as the lab specifications. We have gone though everything,
and it all seems okay. I (John) think it is in subBytes, but I really
do not know. I hope that the fact that this is fully-functioning lab
that compiles, runs, and does all of the work persuades you to
consider our time and the rest of the lab with high regards.